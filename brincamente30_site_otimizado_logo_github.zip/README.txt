BRINCAMENTE 30 - SITE OTIMIZADO COM LOGO

Este pacote já está pronto para substituir no GitHub Pages.
Inclui:
- index.html
- pasta assets com imagens otimizadas
- logo correta do site

PUBLICAÇÃO/ATUALIZAÇÃO:
1. Extraia o ZIP.
2. No seu repositório do GitHub Pages, apague os arquivos antigos do site.
3. Envie o novo index.html e a pasta assets.
4. Aguarde 1 a 3 minutos e atualize a página.
